﻿using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text.RegularExpressions;
using System.Text;
using System;
using System.Numerics;

static class SolutionTemplate
{
    static long modPow(long v, long p, long mod)
    {
        if (p == 0)
            return 1;
        if (p == 1)
            return v;

        long add = 1;
        while (p > 1)
        {
            if (p % 2 == 1)
            {
                add *= v;
                add %= mod;
            }
            v = (v * v) % mod;
            p = p / 2;
        }
        return (v * add) % mod;
    }


    public static List<T> GetOrAddNew<K, T>(this Dictionary<K, List<T>> dic, K key)
    {
        if (dic == null) throw new ArgumentNullException();

        return (dic[key] = dic.ContainsKey(key) ? dic[key] : new List<T>());
    }

    public static V GetValueOrDefault<K, V>(this Dictionary<K, V> dic, K key)
    {
        if (dic == null) throw new ArgumentNullException();
        if (dic.ContainsKey(key))
            return dic[key];
        return default(V);

    }

    public static void AddOrSet<K>(this Dictionary<K, long> dic, K key, long add)
    {
        if (dic == null) throw new ArgumentNullException();

        dic[key] = dic.GetValueOrDefault(key) + add;
    }


    public static void AddOrSet<K>(this Dictionary<K, int> dic, K key, int add)
    {
        if (dic == null) throw new ArgumentNullException();

        dic[key] = dic.GetValueOrDefault(key) + add;
    }


    public static void AddOrSetRemove<K>(this Dictionary<K, long> dic, K key, long add)
    {
        if (dic == null) throw new ArgumentNullException();

        dic[key] = dic.GetValueOrDefault(key) + add;

        if (dic[key] == 0)
        {
            dic.Remove(key);
        }
    }


    public static void AddOrSetRemove<K>(this Dictionary<K, int> dic, K key, int add)
    {
        if (dic == null) throw new ArgumentNullException();

        dic[key] = dic.GetValueOrDefault(key) + add;


        if (dic[key] == 0)
        {
            dic.Remove(key);
        }
    }

    public static void RemoveKeyWhen<K, V>(this Dictionary<K, V> dic, K key, V val)
    {
        if (dic == null) throw new ArgumentNullException();

        if (dic.ContainsKey(key) && object.Equals(dic[key], val))
        {
            dic.Remove(key);
        }
    }

    public static void RemoveAllWhen<K, V>(this Dictionary<K, V> dic, V val)
    {
        if (dic == null) throw new ArgumentNullException();

        var keys = dic.Keys.ToList();
        foreach (var item in keys)
        {
            if (object.Equals(dic[item], val))
            {
                dic.Remove(item);
            }
        }
    }

    public static Dictionary<T, int> ToCountDictionary<T>(this IEnumerable<T> enm)
    {
        return enm.GroupBy(el => el).ToDictionary(k => k.Key, val => val.Count());
    }

    public static Dictionary<T, int> ToIndexDictionary<T>(this IEnumerable<T> enm)
    {
        return enm.Select((el, i) => new { val = el, index = i }).ToDictionary(key => key.val, val => val.index);
    }

    static long readLong()
    {
        return long.Parse(Console.ReadLine().Trim());
    }

    static int readInt()
    {
        return int.Parse(Console.ReadLine().Trim());
    }

    static long[] readLongs()
    {
        return Array.ConvertAll(Console.ReadLine().Trim().Split(), long.Parse);
    }

    static int[] readInts(int add = 0)
    {
        return Array.ConvertAll(Console.ReadLine().Trim().Split(), el => int.Parse(el) + add);
    }

    static string[] readStrings()
    {
        return Console.ReadLine().Trim().Split();
    }

    static string readString()
    {
        return Console.ReadLine().Trim();
    }

    public static int readInt(this StreamReader str)
    {
        if (str == null) throw new ArgumentNullException();
        return int.Parse(str.ReadLine().Trim());
    }


    public static int[] readInts(this StreamReader str)
    {
        if (str == null) throw new ArgumentNullException();
        return Array.ConvertAll(str.ReadLine().Trim().Split(), int.Parse);
    }

    static StringBuilder WriteArray(StringBuilder sb, IEnumerable lst, string delimeter)
    {
        if (lst == null)
            throw new ArgumentNullException(nameof(lst));
        if (sb == null)
            throw new ArgumentNullException(nameof(sb));

        foreach (var el in lst)
        {
            sb.Append(el);
            if (delimeter != null)
                sb.Append(delimeter);
        }
        return sb;
    }

    static StringBuilder WriteObject(StringBuilder sb, object obj, string delimeter)
    {
        if (obj == null)
            throw new ArgumentNullException(nameof(obj));
        if (sb == null)
            throw new ArgumentNullException(nameof(sb));

        sb.Append(obj);
        if (delimeter != null)
            sb.Append(delimeter);
        return sb;
    }

    static void Write2DimArr<T>(this T[,] arr, string delimeter = " ", string delimeter2 = "\n")
    {
        if (arr == null)
            throw new ArgumentNullException(nameof(arr));

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < arr.GetLength(0); i++)
        {
            for (int j = 0; j < arr.GetLength(1); j++)
            {
                WriteObject(sb, arr[i, j], delimeter);
            }
            sb.Append(delimeter2);
        }
        Console.Write(sb.ToString());
    }


    static void Write(this object obj, string delimeter = " ")
    {
        if (obj == null)
            throw new ArgumentNullException(nameof(obj));

        var enm = obj as IEnumerable;
        StringBuilder sb = new StringBuilder();
        if (enm != null)
            WriteArray(sb, enm, delimeter);
        else
        {
            WriteObject(sb, obj, delimeter);
        }
        Console.Write(sb.ToString());
    }
    static void WriteLine(this object obj, string delimeter = " ")
    {
        obj.Write(delimeter);
        Console.WriteLine();
    }
    static void WriteS(params object[] obj)
    {
        obj.Write(" ");
    }
    static void WriteLineS(params object[] obj)
    {
        obj.WriteLine(" ");
    }

    static bool isLess(string cur, string str)
    {
        if (cur.Length > str.Length)
            return false;

        if (cur.Length < str.Length)
            return true;

        for (int i = 0; i < cur.Length; i++)
        {
            var curd = (int)char.GetNumericValue(cur[i]);
            var strd = (int)char.GetNumericValue(str[i]);
            if (curd < strd)
                return true;
            if (curd > strd)
                return false;
        }
        return false;
    }

    static List<long> factorial(long n, long m)
    {
        var ret = new long[n + 1];
        ret[0] = 1;
        for (long i = 1; i < n + 1; i++)
        {
            ret[i] = (ret[i - 1] * i) % m;
        }
        return ret.ToList();
    }

    static int findLess(IList<Sector> ordered, long val)
    {
        var lst = ordered;
        if (lst == null) throw new ArgumentNullException();


        if (lst.Count < 1) return -1;

        var l = -1;
        var r = lst.Count;

        while (r - l > 1)
        {
            var cur = (l + r) / 2;
            if (lst[cur].e >= val)
            {
                r = cur;
            }
            else
            {
                l = cur;
            }

        }
        return l;

    }


    static int findGreate(IList<Sector> ordered, long val)
    {
        var lst = ordered;
        if (lst == null) throw new ArgumentNullException();


        if (lst.Count < 1) return -1;

        var l = -1;
        var r = lst.Count;

        while (r - l > 1)
        {
            var cur = (l + r) / 2;
            if (lst[cur].s <= val)
            {
                l = cur;
            }
            else
            {
                r = cur;
            }

        }
        return r;

    }

    class Sector
    {

        public long s;
        public long e;
        public long id;
    }

    private static void Main(string[] args)
    {

        var arr = readLongs();
        var x = arr[0];
        var y = arr[1];
        var ax = arr[2];
        var ay = arr[3];
        var bx = arr[4];
        var by = arr[5];

        arr = readLongs();
        var sx = arr[0];
        var sy = arr[1];
        var t = arr[2];

        List<Tuple<long, long>> reachable = new List<Tuple<long, long>>();
        long prevdist = long.MaxValue;
        bool f = true;
        var cxn = -1L;
        var cyn = -1L;
        while (f)
        {
            cxn = cxn == -1 ? x : ax * cxn + bx;
            cyn = cyn == -1 ? y : ay * cyn + by;

            var curdist = Math.Abs(cxn - sx) + Math.Abs(cyn - sy);
            if (curdist > prevdist && curdist > t)
            {
                break;
            }
            if (curdist <= t)
            {
                reachable.Add(Tuple.Create(cxn, cyn));

            }
            prevdist = curdist;
        }

        var cnt = 0;

        for (int i = 0; i < reachable.Count; i++)
        {
            for (int j = i; j < reachable.Count; j++)
            {
                var dist = Math.Abs(reachable[i].Item1 - reachable[j].Item1) + Math.Abs(reachable[i].Item2 - reachable[j].Item2) +
                    Math.Min(
                        Math.Abs(reachable[i].Item1 - sx) + Math.Abs(reachable[i].Item2 - sy),
                        Math.Abs(sx - reachable[j].Item1) + Math.Abs(sy - reachable[j].Item2)
                    );
                if (dist > t)
                {
                    break;
                }
                cnt = Math.Max(cnt, j - i + 1);
            }
        }
        cnt.WriteLine();


    }
}